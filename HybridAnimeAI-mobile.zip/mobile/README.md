# Anime AI Buddy - mobile (installable web app)

Android (Chrome) aur iPhone (Safari) dono par chalta hai. Link kholo -> "Install app" / "Add to Home Screen" -> ho gaya.

## Host karna (free)
A) GitHub Pages: repo **public** ho -> Settings -> Pages -> Source = "GitHub Actions" -> Actions -> "Publish mobile app" -> Run workflow. Link: https://<user>.github.io/<repo>/
B) Netlify Drop (netlify.com/drop): `mobile` folder drag-and-drop. Link turant mil jaata hai.

## Update
`mobile/sw.js` me VERSION badhao (aur `app.js` me APP_VERSION) -> push. Phone par app khud naya version utha leta hai aur restart ho jaata hai. Offline me purana version chalta rehta hai.

## Limits (browser app hone ki wajah se)
- Dusre apps ke upar float nahi kar sakta (iske liye native Android app chahiye).
- Voice sunna phone ke browser ki speech service se hota hai, internet chahiye.
- Reminders tabhi bajte hain jab app khula/chalu ho.
- Offline me: time, date, reminders, calculator, apps kholna, search, chhoti baat-cheet. Poori AI baat-cheet ke liye internet + Gemini key.

## v2.1 me naya
- Gemini ka jawab streaming se: text turant dikhta hai aur pehle sentence se hi bolna shuru (tez).
- 💬 chat history, neeche quick-buttons (time, timer, mausam, joke, gaana, search, battery).
- Mausam (free, key nahi chahiye) aur battery commands; reminders dikhao/hatao.
- Naam/gender/personality ka achha popup; pet ko bolte waqt tap karo = chup.
- Rate-limit par ek baar auto retry.

## v2.2: Offline AI (phone ke andar)
Settings -> AI & App -> "Download offline AI" (~400 MB, Wi-Fi par). Model: Qwen2.5-0.5B (4-bit), transformers.js se browser me chalta hai.
Internet na ho (ya Gemini key na ho, ya online jawab fail ho) to ye jawab deta hai. Hindi me kamzor, Gemini se kam smart. WebGPU wale phone par tez, baaki par WASM (dheema).
Library cdn.jsdelivr.net se ek baar aati hai aur cache ho jaati hai; model huggingface se aata hai aur browser cache me rehta hai.

## v2.3: aur aasaan
- Pehli baar 3-step wizard: naam -> character -> (optional) Gemini key. Key ke bina bhi sab local kaam chalta hai.
- ❓ Help: har example par tap = turant chalta hai.
- ✅ Tasks & Notes (bol kar ya likh kar), alarm/reminder clock time se ("kal subah 7 baje alarm"), focus/pomodoro mode, dice/coin.
- Pet ke saath 💗 bond level (roz aane aur baat karne se badhta hai).

## v2.4: fixes + extras
- Lambi baat me "time"/"date"/"hi" aane par ab galti se ghadi nahi batata, sawal AI ko jaata hai.
- Kisi bhi shehar ka mausam ("weather in London", "Delhi ka mausam").
- App band tha to jo reminder chhoot gaye, wo khulte hi bata deta hai.
- Backup/Restore (settings, tasks, notes, reminders, chat; API key backup me nahi jaati).
- Install chip (ek tap me install) aur 🎧 Hands-free chip.
