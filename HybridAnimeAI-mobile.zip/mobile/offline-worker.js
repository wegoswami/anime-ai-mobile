/* Offline AI brain: a small open model (Qwen2.5-0.5B-Instruct, 4-bit) running inside the phone's browser
   through transformers.js. The library and model are downloaded once and cached; after that no internet is needed.
   Runs in a Web Worker so the pet never freezes while it thinks. */
const LIB_VERSIONS = ["3.7.6", "3.5.1", "3.3.3", "3.0.2"];     // first one that loads wins
let T = null, gen = null, loadedKey = "";

async function loadLib() {
  if (T) return T;
  let last;
  for (const v of LIB_VERSIONS) {
    try { T = await import(`https://cdn.jsdelivr.net/npm/@huggingface/transformers@${v}/dist/transformers.min.js`); return T; }
    catch (e) { last = e; }
  }
  throw new Error("Could not download the AI library (" + (last && last.message || last) + ")");
}

async function load(model, device) {
  if (gen && loadedKey === model) return;
  const lib = await loadLib();
  lib.env.allowLocalModels = false; lib.env.useBrowserCache = true;
  const files = {};
  const progress_callback = (p) => {
    if (p && p.status === "progress" && p.file) { files[p.file] = { loaded: p.loaded || 0, total: p.total || 0 }; postMessage({ type: "progress", files }); }
  };
  const make = (dev) => lib.pipeline("text-generation", model, { device: dev, dtype: "q4", progress_callback });
  try { gen = await make(device); }
  catch (e) { if (device !== "wasm") gen = await make("wasm"); else throw e; }   // WebGPU not usable -> slower but universal WASM
  loadedKey = model;
}

onmessage = async (ev) => {
  const m = ev.data;
  try {
    if (m.type === "load") { await load(m.model, m.device); postMessage({ type: "ready" }); }
    else if (m.type === "chat") {
      if (!gen) await load(m.model, m.device);
      const streamer = new T.TextStreamer(gen.tokenizer, { skip_prompt: true, skip_special_tokens: true, callback_function: (t) => postMessage({ type: "tok", id: m.id, text: t }) });
      await gen(m.messages, { max_new_tokens: m.max || 140, do_sample: true, temperature: 0.7, top_p: 0.9, repetition_penalty: 1.1, streamer });
      postMessage({ type: "done", id: m.id });
    }
  } catch (err) { postMessage({ type: "error", id: m.id, error: String((err && err.message) || err) }); }
};
